function click(elementId) {
    document.getElementById(elementId).click();
}
